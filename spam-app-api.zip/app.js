require('dotenv').config();
const express = require("express");
const bodyParser = require("body-parser");
const db = require("./models");
const app = express();

app.use(bodyParser.json());
require("./routes/auth.routes")(app);
require("./routes/contact.routes")(app);
require("./routes/spam.routes")(app);
require("./routes/search.routes")(app);

db.sequelize.sync();

app.listen(process.env.PORT, () => {
  console.log(`Server running on port ${process.env.PORT}`);
});
