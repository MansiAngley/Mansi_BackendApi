# Spam App API
A RESTful API for spam number detection and user search.